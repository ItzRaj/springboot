# Deploy your Springboot application to AWS EC2

### Deployment architecture

![alt text](springboot-aws-deploy.png)

## How to deploy

TBD
