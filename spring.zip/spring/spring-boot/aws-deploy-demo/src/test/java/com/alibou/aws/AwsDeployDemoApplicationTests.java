package com.alibou.aws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsDeployDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
